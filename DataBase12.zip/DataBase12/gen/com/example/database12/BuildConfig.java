/** Automatically generated file. DO NOT MODIFY */
package com.example.database12;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}