package com.example.database12;



import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.os.Build;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_main);
		
		final String database_name="contacts.db";
		final String table_name="contactdetails";
		SQLiteDatabase sqldb;
		Cursor c;
		TextView tv;
		try{
			sqldb =openOrCreateDatabase(database_name,SQLiteDatabase.CREATE_IF_NECESSARY,null);
			sqldb.execSQL("create table"+table_name+"(ID INTEGER PRIMARY KEY auto"
					+ "Name TEXT, PhoneNo LONG)");
			ContentValues cv=new ContentValues();
			cv.put("Name", "Jennifer");
			cv.put("PhoneNo", 1500543546);
			sqldb.insertOrThrow(table_name,null,cv);
			c=sqldb.query(table_name,null,null,null,null,null,null);
			tv=(TextView)findViewById(R.id.textView1);
			if(c.moveToFirst()){
				while(c.isAfterLast()==false){
					tv.append("\n"+c.getString(1));
					c.moveToNext();
				}
			}
			if(c.isClosed()==false){
				c.close();
			}
		}catch(Exception e){
			
		}
		
		

		
	}

	
	

}
