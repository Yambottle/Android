package com.example.demohttp;

import java.util.ArrayList; 
import java.util.HashMap; 
import java.util.List; 
import java.util.Map; 

public class BuildData {
	
	    public BuildData() { 
	    } 
	     
	    public BuildServer getBuildServer(){ 
	        BuildServer BuildServer = new BuildServer(1001,"jack","�Ϻ�������"); 
	        return BuildServer; 
	    } 
	    public List<BuildServer> getListBuildServer(){ 
	        List<BuildServer> list = new ArrayList<BuildServer>(); 
	        BuildServer BuildServer1 = new BuildServer(1001,"jack","�Ϻ�������"); 
	        BuildServer BuildServer2 = new BuildServer(1002,"rose","�Ϻ�������"); 
	        BuildServer BuildServer3 = new BuildServer(1003,"mick","�Ϻ�������"); 
	        list.add(BuildServer1); 
	        list.add(BuildServer2); 
	        list.add(BuildServer3); 
	        return list; 
	    } 
	     
	    public List<String> getListString(){ 
	        List<String> list = new ArrayList<String>(); 
	        list.add("����"); 
	        list.add("�Ϻ�"); 
	        list.add("����"); 
	        return list; 
	    } 
	     
	    public List<Map<String,Object>> getListMaps(){ 
	        List<Map<String,Object>> list = new ArrayList<Map<String,Object>>(); 
	        Map<String,Object> map1 = new HashMap<String, Object>(); 
	        Map<String,Object> map2 = new HashMap<String, Object>(); 
	        map1.put("id", 1001); 
	        map1.put("name", "jack"); 
	        map1.put("address", "����"); 
	        map2.put("id", 1001); 
	        map2.put("name", "rose"); 
	        map2.put("address", "�Ϻ�"); 
	        list.add(map1); 
	        list.add(map2); 
	        return list; 
	    } 
} 