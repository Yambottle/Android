package com.example.db2;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.db2.R;

public class MainActivity extends Activity {
 	   
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);
			final String DATABASE_NAME = "Contacts.db";
		     final String TABLE_NAME = "ContactDetails";
		     SQLiteDatabase sqldb;
		     Cursor c;
		     TextView tv;
	         try{ 
	         sqldb = openOrCreateDatabase(DATABASE_NAME,SQLiteDatabase.CREATE_IF_NECESSARY,null);
	         sqldb.execSQL("create table "+TABLE_NAME+"(id INTEGER PRIMARY KEY autoincrement,Name TEXT,PhoneNo LONG)");
	         ContentValues cv = new ContentValues();
	         cv.put("Name","Danger");
	         cv.put("PhoneNo",1500543546);
	         sqldb.insertOrThrow(TABLE_NAME, null,cv);
	         
	         cv.put("Name","Jennifer");
	         cv.put("PhoneNo",150657834);
	         sqldb.insertOrThrow(TABLE_NAME, null,cv);
	                           
	         c = sqldb.query(TABLE_NAME,null,null,null,null,null,null);
	         
	         tv = (TextView)findViewById(R.id.textView1);
	         if(c.moveToFirst())
	         {
	        	 while(c.isAfterLast()== false)
	        	 {
	        		 tv.append("\n"+c.getString(1));
	        		 c.moveToNext();
	        		 
	        	 }
	        	 
	        	 
	         }
	         if(c.isClosed()==false)
	         {
	        	 c.close();
	         }
	   
	   
   }
	        catch(Exception ex)
	        {
	          Log.e("Error:",ex.toString());	
	        }
	        }
}
