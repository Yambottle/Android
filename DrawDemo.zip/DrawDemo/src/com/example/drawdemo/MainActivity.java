package com.example.drawdemo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;

import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BaiduMap.OnMapTouchListener;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Polyline;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.UiSettings;
import com.baidu.mapapi.model.LatLng;



/**
 * ��ʾMapView�Ļ��÷�
 */
public class MainActivity extends Activity implements OnMapTouchListener {

    private MapView mMapView;
    private BaiduMap mBaiduMap;
    private UiSettings mUiSettings;
    
    private Button startButton, resetButton, clearButton;
    
    LinkedList<Polyline> polylines;
    Polyline dottedPolyLine;
    private Point point1, point2, point3;
    
    boolean drawFlag = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
    super.onCreate(savedInstanceState);

    requestWindowFeature(Window.FEATURE_NO_TITLE);
    // ��ʹ��SDK�����֮ǰ��ʼ��context��Ϣ������ApplicationContext
    // ע��÷���Ҫ��setContentView����֮ǰʵ��
    SDKInitializer.initialize(getApplicationContext());
    setContentView(R.layout.activity_main);
    mMapView = (MapView) findViewById(R.id.bmapView);
    mBaiduMap = mMapView.getMap();
    mUiSettings = mBaiduMap.getUiSettings();
    polylines = new LinkedList<Polyline>();
    
    startButton = (Button) findViewById(R.id.draw);
    resetButton = (Button) findViewById(R.id.reset);
    clearButton = (Button) findViewById(R.id.clear);
    
    mBaiduMap.setOnMapTouchListener(this);
    startButton.setOnClickListener(new OnClickListener() {
		public void onClick(View v) {
			if(drawFlag){
				startButton.setText("绘制");
				mUiSettings.setAllGesturesEnabled(true);
    			drawFlag = false;
			}else{
				startButton.setText("完成");
				mUiSettings.setAllGesturesEnabled(false);
    			drawFlag = true;
			}
		}
	});
    resetButton.setOnClickListener(new OnClickListener() {
		public void onClick(View v) {
			if(!polylines.isEmpty()){
				polylines.getLast().remove();
		        polylines.remove(polylines.getLast());
			}
		}
	});
    clearButton.setOnClickListener(new OnClickListener() {
		public void onClick(View v) {
			mBaiduMap.clear();
			polylines.clear();
		}
	});
    }

    @Override
    protected void onPause() {
        super.onPause();
        // activity ��ͣʱͬʱ��ͣ��ͼ�ؼ�
        mMapView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // activity �ָ�ʱͬʱ�ָ���ͼ�ؼ�
        mMapView.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // activity ���ʱͬʱ��ٵ�ͼ�ؼ�
        mMapView.onDestroy();
    }


	@Override
	public void onTouch(MotionEvent event) {
		
		if(event.getAction() == MotionEvent.ACTION_DOWN){
			
			point1 = getPointXY(event);
		}else if(event.getAction() == MotionEvent.ACTION_MOVE){
			point3 = getPointXY(event);
			if(drawFlag){
				drawDottedLine(point1, point3);
			}
		}else if(event.getAction() == MotionEvent.ACTION_UP){
			point2 = getPointXY(event);
			if(drawFlag){
				drawLine(point1, point2);
				dottedPolyLine.remove();
			}
		}
	}
	
	public LatLng coorConvert(Point point){
		return mBaiduMap.getProjection().fromScreenLocation(point);
	}
	
	public Point getPointXY(MotionEvent event){
		Point point = new Point();
		point.x = (int) event.getX();
		point.y = (int) event.getY();
		return point;
	}
	
	public void drawLine(Point point1, Point point2){
		List<LatLng> points = new ArrayList<LatLng>();
        points.add(coorConvert(point1));
        points.add(coorConvert(point2));
        PolylineOptions PolylineOptions = new PolylineOptions().width(10)
                .color(0xAAFF0000).points(points);
        Polyline mPolyline = (Polyline) mBaiduMap.addOverlay(PolylineOptions);
        polylines.add(mPolyline);
	}
	
	public void drawDottedLine(Point point1, Point point3){
		if(dottedPolyLine != null){
			dottedPolyLine.remove();
		}
		List<LatLng> points = new ArrayList<LatLng>();
        points.add(coorConvert(point1));
        points.add(coorConvert(point3));
        PolylineOptions PolylineOptions = new PolylineOptions().width(10)
                .color(0xAAFF0000).points(points);
        dottedPolyLine = (Polyline) mBaiduMap.addOverlay(PolylineOptions);
        dottedPolyLine.setDottedLine(true);
	}
}
