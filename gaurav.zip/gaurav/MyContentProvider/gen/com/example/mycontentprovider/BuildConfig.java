/** Automatically generated file. DO NOT MODIFY */
package com.example.mycontentprovider;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}