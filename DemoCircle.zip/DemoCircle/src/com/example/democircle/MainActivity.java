package com.example.democircle;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		MyView myview=new MyView(this);
		setContentView(myview);

	}

	private class MyView extends View{
		public MyView(Context context){
			super(context);
		}
		
		@Override
		protected void onDraw(Canvas canvas){
			super.onDraw(canvas);
			
			//����
			Paint paint= new Paint();
			paint.setAntiAlias(true);
			//
			paint.setColor(Color.GREEN);
			paint.setStyle(Paint.Style.STROKE);
			paint.setStrokeWidth(6);
			RectF oval1=new RectF(10,10,50,50);//����Ϊ�����ξ�������
			canvas.drawArc(oval1, -90, 270, false, paint);//270Ϊת���Ƕȣ�Ӧ���ٷֱ�ȡֵ��			
			
		}
	}
}
