package com.example.demo;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		MyView myview=new MyView(this);
		setContentView(myview);

	}

	private class MyView extends View{
		public MyView(Context context){
			super(context);
		}
		
		@Override
		protected void onDraw(Canvas canvas){
			super.onDraw(canvas);
			
			//����
			Paint paint= new Paint();
			paint.setAntiAlias(true);
			Paint paint2= new Paint();
			paint2.setAntiAlias(true);
			//
			paint.setColor(Color.BLUE);
			paint.setStyle(Paint.Style.FILL);
			paint.setStrokeWidth(1);
			paint2.setColor(Color.BLACK);
			paint2.setStyle(Paint.Style.STROKE);
			paint2.setStrokeWidth(2);
			canvas.drawRect(10, 10, 170, 30, paint);
			canvas.drawRect(10, 10, 170, 30, paint2);
			canvas.drawRect(10, 10, 200, 30, paint2);
			
			//������
			paint.setColor(Color.YELLOW);
			paint.setStyle(Paint.Style.FILL);
			paint.setStrokeWidth(2);
			paint2.setColor(Color.BLACK);
			paint2.setStyle(Paint.Style.STROKE);
			paint2.setStrokeWidth(1);
			//
			Path path=new Path();
			path.moveTo(171, 31);
			path.lineTo(165,35);
			path.lineTo(175, 35);
			path.close();
			canvas.drawPath(path, paint);
			canvas.drawPath(path, paint2);
			
			
		}
	}
}
