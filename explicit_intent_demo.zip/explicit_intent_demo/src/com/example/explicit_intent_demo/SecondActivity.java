package com.example.explicit_intent_demo;

import android.app.Activity;
import android.app.Instrumentation.ActivityResult;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class SecondActivity extends Activity {

	/* (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		//associate the activity_second.xml with secondActivity.java
		 setContentView(R.layout.activity_second);
		 Intent i=getIntent();
		 Bundle b=i.getExtras();
		 double marks=b.getDouble("marks1");
		 Toast.makeText(getBaseContext(),"marks is "+marks,Toast.LENGTH_SHORT).show();
		 Log.i("marks recieved from intent",""+marks+"");
		
		 //to return result back to caller
		 String res="fail";
		 b.putString("result",res);
		 i.putExtras(b);
		 setResult(Activity.RESULT_OK,i);
	}

}
