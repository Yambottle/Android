/** Automatically generated file. DO NOT MODIFY */
package com.example.explicit_intent_demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}