package com.example.db2;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.db2.R;

public class MainActivity extends Activity {
 	   
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);
			final String DATABASE_NAME = "Contacts.db";
	//we declare a string variable containing the
	//name of database that we want to create or open
		     final String TABLE_NAME = "ContactDetails";
    //the table name to be created
		     SQLiteDatabase sqldb;
	//we require this class to execute sql statements
		     
		     Cursor c;
	//cursor is like resultset,it hold the value returned	
	//after executing select statement	     
		     TextView tv;
	         try{ 
 sqldb = openOrCreateDatabase(DATABASE_NAME,
		 SQLiteDatabase.CREATE_IF_NECESSARY,null);
//in the above line we try to create or open a database
 //this method takes 3 parameters
 //1st parameter-name/path of database to create/open
 
 //2nd parameter-here you can give many values,
 //the value given here indicates that we must 
 //create a new database if required
 
 //3rd parameter specifies the errorhandler code,
 //we can keep it null
 
 
 sqldb.execSQL("create table "+TABLE_NAME+
		 "(id INTEGER PRIMARY KEY autoincrement,Name TEXT,PhoneNo LONG)");
//above line creates a table with first column as identity coloumn
 //for this you need to write autoincrement
 
 ContentValues cv = new ContentValues();
 //contentvalues is a predefined class,
 //which is used to insert/update/delete values in table
 //you can insert one row at a time using the obj of content value
 
	         cv.put("Name","Danger");
	         cv.put("PhoneNo",1500543546);
	         sqldb.insertOrThrow(TABLE_NAME, null,cv);
//you can use put method to add a coloumn value
  //here Name is the coloumn name
   //Danger is the value
	   //insertorthrow is used to insert a row or throw exception
	         //1st param-name of the table
	         //2nd param-is used to specify column name,if you dnt want to
	         //specify coloumn name then write null
	         //3rd param-is a map of values to be inserted
	         //in our case we use cv,which is obj of contentvalues
	         cv.put("Name","Jennifer");
	         cv.put("PhoneNo",150657834);
	         sqldb.insertOrThrow(TABLE_NAME, null,cv);
	//insert the values for second row   
	         cv.put("Name","kunal");
	         cv.put("PhoneNo",850909873);
	         sqldb.insertOrThrow(TABLE_NAME, null,cv);
	                           
	  c = sqldb.query(TABLE_NAME,null,null,null,null,null,null);
	  //query method is used to query the database
	  //it takes 7 parameters
	  //and returns an object of cursor type
	  //the parameters used here are explained on page 6.16
	  //you see we have many null values present her
	  //so if you dnt want to give any value,you can put null
	         
	         tv = (TextView)findViewById(R.id.textView1);
	  //here we find the textview control using its ID       
	         if(c.moveToFirst())//moves the cursor to row 1
	         {
	        	 while(c.isAfterLast()== false)
	        	 {//check if the cursor is not after the last row
	        		 tv.append("\n"+c.getString(1));
	        		 //append the value retrieved in textview
	        		 //here we are retriving the value in Name coloumn
	        		 c.moveToNext();
	        		 //move to next row
	        		 
	        	 }
	        	 
	        	 
	         }
	         if(c.isClosed()==false)
	         {
	        	 c.close();
	         }
	   
	   
   }
	        catch(Exception ex)
	        {
	          Log.e("Error:",ex.toString());	
	        }
	        }
}
