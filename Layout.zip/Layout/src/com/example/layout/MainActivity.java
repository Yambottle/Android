package com.example.layout;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class MainActivity extends Activity {

	 @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.fragment_main);
	        Button b=(Button) findViewById(R.id.button1);
	//earlier we had created event by implementing from onClickEvent as follows:
	//public class MainActivity extends Activity implements OnClickListener{}
	//their is a second way as you see below,here we make use of anonymous class


	        b.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
				
	//moving to activity 2 using intent,start activity methods takes intent as 
	//parameter
	//inside constructor of intent you  write the 
	//source_activity_class.this,target_activity_class.class
	//this will make the control shift to activity2 when the use clicks the button

					startActivity(new Intent(MainActivity.this,Activity2.class));
					
				}
			});
	    }
}
/*
public class MainActivity extends Activity implement OnClickListener{

@Override
   protected void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
       setContentView(R.layout.fragment_main);
       Button b=(Button) findViewById(R.id.button1);
       
       b.setOnClickListener(this);
       }		
		@Override
		public void onClick(View v) {
			Intent i=new Intent(MainActivity.this,Activity2.class);
			startActivity(i);
			
		}
		
   }
*/