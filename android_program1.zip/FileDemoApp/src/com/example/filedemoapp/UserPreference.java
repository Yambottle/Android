package com.example.filedemoapp;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class UserPreference extends Activity {

	LinearLayout mScreen;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_preference);
		setColorOnPreference();
	}
	public void saveBgColorPreference()
	 
	{
		RadioGroup g = (RadioGroup) findViewById(R.id.prefgroup);

		int selected = g.getCheckedRadioButtonId();
	 
		RadioButton b = (RadioButton) findViewById(selected);
	String selectedValue = (String) b.getText();
	
SharedPreferences myPrefs = this.getSharedPreferences("myPrefs",MODE_WORLD_READABLE);
	 
	SharedPreferences.Editor prefsEditor = myPrefs.edit();
	 
	prefsEditor.putString("bgcolor", selectedValue);
	 
	prefsEditor.commit();
	 
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.user_preference, menu);
		return true;
	}

	public void setColorOnPreference()
	 
	{
	 
	mScreen = (LinearLayout) findViewById(R.id.myScreen);
	 
	SharedPreferences myPrefs2 = this.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
	 
	String prefName = myPrefs2.getString("bgcolor", "Blue");
	 
	if(prefName.equals("Blue"))
	 
	mScreen.setBackgroundColor(0xff0000ff);
	 
	else
	 
	mScreen.setBackgroundColor(0xffff0000);
	 
	}

	public void savepreferencesClicked(View v) {
		 
		saveBgColorPreference();
		 
		setColorOnPreference();
		 
		}

	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
