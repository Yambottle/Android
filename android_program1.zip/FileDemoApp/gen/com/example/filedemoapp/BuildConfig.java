/** Automatically generated file. DO NOT MODIFY */
package com.example.filedemoapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}