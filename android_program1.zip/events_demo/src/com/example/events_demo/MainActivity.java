package com.example.events_demo;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Activity implements OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b=(Button)findViewById(R.id.button1);
        b.setOnClickListener(this);
        
    }


	@Override
	public void onClick(View v) {
		  EditText b=(EditText)findViewById(R.id.editText1);
		  String name=b.getText().toString();
		  if(name.length()!=0)
		  Toast.makeText(MainActivity.this,"Hello Mr. "+name,Toast.LENGTH_SHORT).show();
		  else
			  Toast.makeText(MainActivity.this,"please enter your name",Toast.LENGTH_SHORT).show();  
		
	}
}
