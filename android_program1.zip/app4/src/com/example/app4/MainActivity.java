package com.example.app4;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Activity implements OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Button b=(Button)findViewById(R.id.button1);
        b.setOnClickListener(new OnClickListener() {
			
			
			
			@Override
			public void onClick(View v) {
				EditText e1=(EditText)findViewById(R.id.editText1);
				EditText e2=(EditText)findViewById(R.id.editText2);
				String name=e1.getText().toString();
				String password=e2.getText().toString();
				Toast.makeText(MainActivity.this,"name: "+name+" password: "+password, Toast.LENGTH_LONG).show();
				if(name.equals("kunal") && password.equals("pass"))
				{
			    startActivity(new Intent( MainActivity.this,SecActivity.class));
				}
				else{
				Toast.makeText(MainActivity.this,"your credentials donot match", Toast.LENGTH_LONG).show();
				}}
			
		});
        
        //to create event using onclicklistner,implement the onclicklistner class and override the onclick method outside this class
        // b.setOnClickListener(this); 
		//EditText e1=(EditText)findViewById(R.id.editText1);
        Log.i("Activity1","On create fired");
    }


    @Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.i("Activity 1","on destroy fired");
	}


	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		Log.i("Activity 1","on pause fired");
	}


	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		Log.i("Activity 1","on restart fired");
	}


	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Log.i("Activity 1","on resume fired");
	}


	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		Log.i("Activity 1","on start fired");
	}


	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		Log.i("Activity 1","on stop fired");
	}


	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}
}
