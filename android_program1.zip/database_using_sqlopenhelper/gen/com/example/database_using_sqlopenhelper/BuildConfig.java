/** Automatically generated file. DO NOT MODIFY */
package com.example.database_using_sqlopenhelper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}