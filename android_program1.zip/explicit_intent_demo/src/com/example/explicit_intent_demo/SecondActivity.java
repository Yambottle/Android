package com.example.explicit_intent_demo;

import android.app.Activity;
import android.app.Instrumentation.ActivityResult;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class SecondActivity extends Activity {

	/* (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		//associate the activity_second.xml with secondActivity.java
		 setContentView(R.layout.activity_second);
		 Intent i=getIntent();
		 Bundle b=i.getExtras();
		 String name =b.getString("name");
		 Toast.makeText(getBaseContext(),"name is "+name,Toast.LENGTH_LONG).show();
		 Log.i("name recieved from intent",""+name+"");
		
		 //to return result back to caller
		 String res="fail";
		 b.putString("result",res);
		 i.putExtras(b);
		 setResult(Activity.RESULT_OK,i);
	}

}
