package com.example.explicit_intent_demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends Activity implements OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    	Button b=(Button)findViewById(R.id.button1);
    	b.setOnClickListener(this);
    	
    	
    }
    @Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
    	Intent i=new Intent(MainActivity.this,SecondActivity.class);
    	Bundle b=new Bundle();
    	b.putString("name","kunal");
    	i.putExtras(b);
    	
    //	startActivity(i);
    	//to send value expecting a return
    	startActivityForResult(i,123);
    	//to retrieve and display the returned value
    	
    	
		
	}
    

    /* (non-Javadoc)
	 * @see android.app.Activity#onActivityResult(int, int, android.content.Intent)
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		try{
			
			if((requestCode==123)&&(resultCode==Activity.RESULT_OK))
			{
				
				Bundle b3=data.getExtras();
				String res=b3.getString("result");
				Toast.makeText(getBaseContext(),"result returned from activity 2 is "+res,Toast.LENGTH_LONG).show();
			}
			
		} 
		catch(Exception e)
		{
			 
			e.printStackTrace();
		}
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


	
}
