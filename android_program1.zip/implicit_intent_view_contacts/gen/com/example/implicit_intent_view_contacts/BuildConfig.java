/** Automatically generated file. DO NOT MODIFY */
package com.example.implicit_intent_view_contacts;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}