package com.example.broadcast_reciever_self;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class mybroadcastreciever extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		Toast.makeText(context,"recieved broadcast",Toast.LENGTH_LONG).show();

	}

}
