package com.example.spinner_demo;

import android.app.Activity;
import android.os.Bundle;

public class activity_2 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		 setContentView(R.layout.activity2);
	}
	

}
