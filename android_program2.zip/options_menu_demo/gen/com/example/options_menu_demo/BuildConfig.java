/** Automatically generated file. DO NOT MODIFY */
package com.example.options_menu_demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}