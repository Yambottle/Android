package com.example.options_menu_demo;

import android.app.Activity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.PopupMenu.OnMenuItemClickListener;
import android.widget.Toast;


public class MainActivity extends Activity implements OnMenuItemClickListener{
 private EditText edittext1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edittext1=(EditText)findViewById(R.id.editText1);
        registerForContextMenu(edittext1);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch( item.getItemId()){
        case R.id.Edit:Toast.makeText(getBaseContext() , "You clicked on edit menu", Toast.LENGTH_LONG).show();
             break;
        case R.id.Delete:Toast.makeText(getBaseContext() , "You clicked on delete menu", Toast.LENGTH_LONG).show();
        break;
        case R.id.Save:Toast.makeText(getBaseContext() , "You clicked on save menu", Toast.LENGTH_LONG).show();
        break;
             
        }
        return super.onOptionsItemSelected(item);
    }


	/* (non-Javadoc)
	 * @see android.app.Activity#onContextItemSelected(android.view.MenuItem)
	 */
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		 switch( item.getItemId()){
	        case R.id.Edit:Toast.makeText(getBaseContext() , "You clicked on edit menu", Toast.LENGTH_LONG).show();
	             break;
	        case R.id.Delete:Toast.makeText(getBaseContext() , "You clicked on delete menu", Toast.LENGTH_LONG).show();
	        break;
	        case R.id.Save:Toast.makeText(getBaseContext() , "You clicked on save menu", Toast.LENGTH_LONG).show();
	        break;
	             
	        }
		return super.onContextItemSelected(item);
	}


	/* (non-Javadoc)
	 * @see android.app.Activity#onCreateContextMenu(android.view.ContextMenu, android.view.View, android.view.ContextMenu.ContextMenuInfo)
	 */
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		getMenuInflater().inflate(R.menu.main, menu);
		super.onCreateContextMenu(menu, v, menuInfo);
	}
	public void showpopup(View v)
	{
		
		PopupMenu pm=new PopupMenu(this,v);
		MenuInflater inflater=pm.getMenuInflater();
		inflater.inflate(R.menu.main,pm.getMenu());
		pm.show();
	}


	@Override
	public boolean onMenuItemClick(MenuItem item) {
		// TODO Auto-generated method stub
		 switch( item.getItemId()){
	        case R.id.Edit:Toast.makeText(getBaseContext() , "You clicked on edit menu", Toast.LENGTH_LONG).show();
	            return true;
	        case R.id.Delete:Toast.makeText(getBaseContext() , "You clicked on delete menu", Toast.LENGTH_LONG).show();
	       return true;
	        case R.id.Save:Toast.makeText(getBaseContext() , "You clicked on save menu", Toast.LENGTH_LONG).show();
	       return true;
	       default:
	    	   return false;
	             
	        }
	
	}
	
}
