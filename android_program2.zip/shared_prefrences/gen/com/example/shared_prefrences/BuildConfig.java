/** Automatically generated file. DO NOT MODIFY */
package com.example.shared_prefrences;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}