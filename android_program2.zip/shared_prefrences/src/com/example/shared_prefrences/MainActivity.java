package com.example.shared_prefrences;



import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;


public class MainActivity extends Activity {
public static  final String MYPREFS="mysharedpreferences";
private RadioGroup g1;
private RadioButton b1;
private RadioButton b2;
private RadioButton b3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitymain);
        g1=(RadioGroup)findViewById(R.id.radioGroup1);
        b1=(RadioButton)findViewById(R.id.radio0);
        b2=(RadioButton)findViewById(R.id.radio1);
        b3=(RadioButton)findViewById(R.id.radio2);
        //read the shared preferences
        read_preferences();
      
        
        
    }
  public void read_preferences()
  {
	  
	    LinearLayout mScreen = (LinearLayout) findViewById(R.id.myScreen); 
	    int mode=Activity.MODE_PRIVATE;
        SharedPreferences myprefs=getSharedPreferences(MYPREFS, mode);
        String backcolor=myprefs.getString("color","CYAN");
		if(backcolor.equals("BLUE"))
		mScreen.setBackgroundColor(0xff0000ff);
		else if(backcolor.equals("RED"))
		mScreen.setBackgroundColor(0xffff0000);
		else
		mScreen.setBackgroundColor(0xff00ffff);
		 
		
  }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void save_preferences(View v)
    {
    	SharedPreferences pref =getSharedPreferences(MYPREFS,MODE_PRIVATE);
    	SharedPreferences.Editor edit=pref.edit();
    	if(g1.getCheckedRadioButtonId()==b1.getId())
    	{
    	edit.putString("color", "RED");
    	}
    	else if(g1.getCheckedRadioButtonId()==b2.getId())
    	{
    		
    		edit.putString("color", "BLUE");
    	}
    	else{
    		edit.putString("color", "CYAN");
    		
    	}
    	edit.commit();
    	read_preferences();
    	
    	
    }
}
