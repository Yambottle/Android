/** Automatically generated file. DO NOT MODIFY */
package com.example.implicit_intent1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}