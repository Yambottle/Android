/** Automatically generated file. DO NOT MODIFY */
package com.example.tab_demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}