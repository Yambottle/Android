package com.example.tab_demo;

import android.app.Activity;
import android.app.TabActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;


public class MainActivity extends TabActivity {

	TabHost tabhost;
	TabSpec spec1;
	TabSpec spec2;
	TabSpec spec3;
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initialize the tabhost
        tabhost=(TabHost)findViewById(android.R.id.tabhost);
        tabhost.setup();
        //create tab 1,2,3
        spec1=tabhost.newTabSpec("Tab 1");
        spec2=tabhost.newTabSpec("Tab 2");
        spec3=tabhost.newTabSpec("Tab 3");
        //set the content for tabs
        spec1.setContent(R.id.tab1);
        spec2.setContent(R.id.tab2);
        spec3.setContent(R.id.tab3);
        //set label and icon for tabs
        spec1.setIndicator("E-MAIL",getResources().getDrawable(R.drawable.ic_launcher));
        spec2.setIndicator("MESSAGE",getResources().getDrawable(R.drawable.ic_launcher));
        spec3.setIndicator("CONTACTS",getResources().getDrawable(R.drawable.ic_launcher));
        //ADD THE TABS TO TABHOST
        tabhost.addTab(spec1);
        tabhost.addTab(spec2);
        tabhost.addTab(spec3);
        
        
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
