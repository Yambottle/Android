package com.example.storedata_external_internal;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;


public class MainActivity extends Activity {
	
	private final static String STORETEXT="storetext.txt";
	private EditText edit_text1;
	private TextView text_view3;
	//private ToggleButton toggle_button1;
	private CheckBox check_box1;
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit_text1=(EditText)findViewById(R.id.editText1);
        text_view3=(TextView)findViewById(R.id.textView3);
        check_box1=(CheckBox)findViewById(R.id.checkBox1);
    }
    
    public void save_button_clicked(View v)
    {
    	if(check_box1.isChecked())
    	{
    		
    		store_in_sd();
    	}
    	else
    	{
    		store_in_device();
    		
    	}
    	
    }
    public void read_button_clicked(View v)
    {
    	if(check_box1.isChecked())
    	{
    		
    		read_data_from_sd();
    	}
    	else
    	{
    		read_from_internal();
    		
    	}
    	
    }

  public void store_in_sd() 
  {
	boolean media_available=false;
	boolean media_writable=false;
	String state=Environment.getExternalStorageState();
	if(Environment.MEDIA_MOUNTED.equals(state))
	{
		try{
	String data=edit_text1.getText().toString();
	FileOutputStream fos=new FileOutputStream
	(Environment.getExternalStorageDirectory()+
			"//"+STORETEXT);
	fos.write(data.getBytes());
	fos.close();
	 Toast.makeText(this,
			 "The contents are saved in the external storage at "
	 +Environment.getExternalStorageDirectory()+"//"+STORETEXT, 
	 Toast.LENGTH_LONG).show();
		}	
	 catch (Throwable t) {
		   Toast.makeText(this, "Exception: "+t.toString(), Toast.LENGTH_LONG).show();
		}
	}
	
	  
  }
  public void store_in_device()
  {
	  try {
		 
	    	 
		   OutputStreamWriter out=
				   new OutputStreamWriter(openFileOutput(STORETEXT, 
						   Context.MODE_PRIVATE));
		   out.write("\n"+edit_text1.getText().toString());
		   out.close();
		   Toast.makeText(this, "The contents are saved in the file"+
		   this.fileList().toString(), Toast.LENGTH_LONG).show();
		}
		    	 
		catch (Throwable t) {
		   Toast.makeText(this, "Exception: "+t.toString(), Toast.LENGTH_LONG).show();
		}
	  
  }
  public void read_data_from_sd()
  {
	  try{
	  FileInputStream fis=
			  new FileInputStream(Environment.getExternalStorageDirectory()+
					  "//"+STORETEXT);
	  byte[] reader=new byte[fis.available()];
	  while(fis.read(reader)!=-1)
	  {
		  
		  String mdata=(new String(reader));
		  StringBuilder sb=new StringBuilder();
		  sb.append(mdata+"\n");
		  text_view3.setText(sb);
	  }
	  }
	  catch(Throwable t)
	  {
		  Toast.makeText(this, "Exception: "+t.toString(), Toast.LENGTH_LONG).show();
		  
	  }
  }
  
  public void read_from_internal()
  {
	  
	  try {
		     
		    InputStream in = openFileInput(STORETEXT);
		     
		    if (in != null) {
		     
		    InputStreamReader tmp=new InputStreamReader(in);
		     
		    BufferedReader reader=new BufferedReader(tmp);
		     
		    String str;
		     
		    StringBuilder buf=new StringBuilder();
		     
		    while ((str = reader.readLine()) != null) {
		     
		    buf.append(str+"\n");
		     
		    }
		     
		    in.close();
		    text_view3.setText(buf);
		    }
	  }
		    catch(Throwable t)
		    {
		    	 Toast.makeText(this, "Exception: "+t.toString(), Toast.LENGTH_LONG).show();
		    }
		    
		    
		
		     
	  
		     
  }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
