/** Automatically generated file. DO NOT MODIFY */
package com.example.storedata_external_internal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}