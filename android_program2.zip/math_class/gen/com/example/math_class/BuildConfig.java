/** Automatically generated file. DO NOT MODIFY */
package com.example.math_class;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}