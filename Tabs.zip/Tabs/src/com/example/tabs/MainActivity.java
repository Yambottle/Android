package com.example.tabs;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.os.Build;

public class MainActivity extends ActionBarActivity {
	TabHost th;
	TabSpec ts1;
	TabSpec ts2;
	TabSpec ts3;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_main);
		
		th=(TabHost)findViewById(android.R.id.tabhost);
		th.setup();
		
		ts1=th.newTabSpec("Tab 1");
		ts2=th.newTabSpec("Tab 2");
		ts3=th.newTabSpec("Tab 3");
		
		ts1.setContent(R.id.tab1);
		ts2.setContent(R.id.tab2);
		ts3.setContent(R.id.tab3);
		
		ts1.setIndicator("Edit");
		ts2.setIndicator("Delete");
		ts3.setIndicator("Save");
		
		th.addTab(ts1);
		th.addTab(ts2);
		th.addTab(ts3);
		
	}

	

}
