
package al_nayesh;

public class Mart {

    public static void main(String[] args) {
        //Wel w =new Wel();
        //w.initComponents();
        //Thread t =new Thread(w);
        //t.start();
    	Man man =new Man();
    	man.initComponents();
//        Emp emp=new Emp();
//        emp.initComponents();
//    	Log l=new Log();
//    	l.initComponents();
    }
    
}
