package com.example.maininterdemo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;

public class TabHomeFragment extends Fragment implements OnItemClickListener,OnScrollListener{
	
	Handler handler=new Handler();
	private ArrayList<String> titleList;

	private ListView lv;
	private SimpleAdapter sa;
	private List<Map<String,Object>> dataList;

	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		return inflater.inflate(R.layout.tabhome,container, false);
	}
	
	@Override
	public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		lv=(ListView)view.findViewById(R.id.listView1);
		handler.post(new Runnable() {
			@Override
			public void run() {
				//ListView
				dataList =new ArrayList<Map<String, Object>>();
				sa=new SimpleAdapter(
				getActivity(), getData(),R.layout.itemlayout,//MainActivity.this
				new String[]{"img","item_title","img_content","item_content"}, 
				new int[]{R.id.img,R.id.item_title,R.id.img_content,R.id.item_content});
				lv.setAdapter(sa);
			}
		});
		lv.setOnItemClickListener(this);
		lv.setOnScrollListener(this);
	}

	//------------------------------ListView&&ListItem
	private List<Map<String,Object>> getData(){
		
		titleList=new ArrayList<String>();
		//--��ȡ��Ϣ
		titleList.add("1");titleList.add("2");titleList.add("3");titleList.add("4");titleList.add("5");
		
		for(int i=0;i<titleList.size();i++){//iΪ����
			Map<String,Object> map=new HashMap<String,Object>();
			map.put("img", R.drawable.ic_launcher);
			map.put("item_title", titleList.get(i).toString());
			map.put("img_content", R.drawable.ic_launcher);
			map.put("item_content", "Blog_Content");
			dataList.add(map);
		}
		return dataList;
	}
	//------------------------------ListViewEvents
	@Override
	public void onScroll(AbsListView arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onScrollStateChanged(AbsListView view, int scollState) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// TODO Auto-generated method stub
		Intent intent =new Intent(getActivity(), BlogActivity.class);
		startActivity(intent);
	}
	
}
