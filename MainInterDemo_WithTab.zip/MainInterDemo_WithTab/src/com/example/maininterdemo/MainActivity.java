package com.example.maininterdemo;


import com.example.maininterdemo.TopBar.TopbarClickListener;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends FragmentActivity implements OnClickListener {
	
	private LinearLayout Tabhome,Tabsearch,Tabme;
	private int TabSelectColor=0xFFFFFFFF;
	private int TabNotSelectColor=0xFFADD8E6;
	private ImageButton Ibhome,Ibsearch,Ibme;

	private Fragment fhome,fsearch,fme;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//TopBar
		TopBar Topbar=(TopBar)findViewById(R.id.topbar);
		Topbar.setOnTopbarClickListener(new TopbarClickListener() {
			
			@Override
			public void rightClick() {
				// TODO Auto-generated method stub
				Toast.makeText(MainActivity.this, "right", Toast.LENGTH_SHORT).show();
			}
			
			@Override
			public void leftClick() {
				// TODO Auto-generated method stub
			}
		});
		//Fragment
		initView();
		//TabButton
		tabEvents();
		//initialize first fragment
		setSelect(0);
	}
	//------------------------------Fragment	
	private void initView() {
		Tabhome=(LinearLayout)findViewById(R.id.hometab);
		Tabsearch=(LinearLayout)findViewById(R.id.searchtab);
		Tabme=(LinearLayout)findViewById(R.id.metab);
		Tabhome.setBackgroundColor(TabSelectColor);
			
		Ibhome=(ImageButton)findViewById(R.id.homeimg);
		Ibsearch=(ImageButton)findViewById(R.id.searchimg);
		Ibme=(ImageButton)findViewById(R.id.meimg);
		Ibhome.setBackgroundColor(TabSelectColor);
	}
	
	//------------------------------TabEvents
	private void tabEvents() {
		// TODO Auto-generated method stub
		Tabhome.setOnClickListener(this);
		Tabsearch.setOnClickListener(this);
		Tabme.setOnClickListener(this);
		Ibhome.setOnClickListener(this);
		Ibsearch.setOnClickListener(this);
		Ibme.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		resTab();
		switch(v.getId()){
			case R.id.hometab:
			case R.id.homeimg:
				setSelect(0);
				break;
			case R.id.searchtab:
			case R.id.searchimg:
				setSelect(1);
				break;
			case R.id.metab:
			case R.id.meimg:
				setSelect(2);
				break;
		}
	}
	
	private void resTab() {
		// TODO Auto-generated method stub
		Tabhome.setBackgroundColor(TabNotSelectColor);
		Tabsearch.setBackgroundColor(TabNotSelectColor);
		Tabme.setBackgroundColor(TabNotSelectColor);
		
		Ibhome.setBackgroundColor(TabNotSelectColor);
		Ibsearch.setBackgroundColor(TabNotSelectColor);
		Ibme.setBackgroundColor(TabNotSelectColor);
	}
	private void setSelect(int i) {
		FragmentManager fm =getSupportFragmentManager();
		FragmentTransaction transaction =fm.beginTransaction();
		hideFragment(transaction);
		
		switch(i){
			case 0:
				Tabhome.setBackgroundColor(TabSelectColor);
				Ibhome.setBackgroundColor(TabSelectColor);
			if(fhome==null){
				fhome=new TabHomeFragment();
				transaction.add(R.id.content,fhome);
			}else{
				transaction.show(fhome);
			}
				break;
			case 1:
				Tabsearch.setBackgroundColor(TabSelectColor);
				Ibsearch.setBackgroundColor(TabSelectColor);
				if(fsearch==null){
					fsearch=new TabSearchFragment();
					transaction.add(R.id.content,fsearch);
				}else{
					transaction.show(fsearch);
				}
				break;
			case 2:
				Tabme.setBackgroundColor(TabSelectColor);
				Ibme.setBackgroundColor(TabSelectColor);
				if(fme==null){
					fme=new TabMeFragment();
					transaction.add(R.id.content,fme);
				}else{
					transaction.show(fme);
				}
				break;
			default:
				break;
		}
		transaction.commit();
	}
	
	private void hideFragment(FragmentTransaction transaction) {
		// TODO Auto-generated method stub
		if(fhome!=null){
			transaction.hide(fhome);
		}
		if(fsearch!=null){
			transaction.hide(fsearch);
		}
		if(fme!=null){
			transaction.hide(fme);
		}
	}
	
}
