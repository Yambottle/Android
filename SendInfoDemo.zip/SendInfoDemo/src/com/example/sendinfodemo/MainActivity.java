package com.example.sendinfodemo;

import com.google.gson.Gson;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity implements OnClickListener{
	
	Button sendButton;
	EditText userEditText, pwdEditText;
	
	Handler h= new Handler(){
		@Override
		public void handleMessage(Message msg) {
			Toast.makeText(MainActivity.this, msg.toString(), Toast.LENGTH_LONG).show();
		}
	};
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		sendButton = (Button) findViewById(R.id.button1);
		userEditText = (EditText)findViewById(R.id.editText1);
		pwdEditText = (EditText)findViewById(R.id.editText2);
		
		sendButton.setOnClickListener(this);
	}
	@Override
	public void onClick(View arg0) {
		User user = new User();
		user.setName(userEditText.getText().toString().trim());
		user.setPwd(pwdEditText.getText().toString().trim());
		Gson gson = new Gson();
		String userJasonString = gson.toJson(user);
		new Thread(new AccessNetwork("http://192.168.199.159:8888/gcgl/user.do?method=login",userJasonString, h)).start();
	}
}