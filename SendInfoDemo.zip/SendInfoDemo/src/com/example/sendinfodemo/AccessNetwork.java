package com.example.sendinfodemo;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import android.os.Handler;
import android.os.Message;


public class AccessNetwork implements Runnable{
	private String url;
	private String params;
	private Handler h;
	private static final String APPLICATION_JSON = "application/json";
    private static final String CONTENT_TYPE_TEXT_JSON = "text/json";
	
	public AccessNetwork(String url, String params,Handler h) {
		super();
		this.url = url;
		this.params = params;
		this.h = h;
	}

	@Override
	public void run() {
		Message m = new Message();
		m.obj = sendPost(url, params);
		h.sendMessage(m);
	}
	
	public static String sendPost(String url, String params){
		String displayString="1";
		List<NameValuePair> nameValuePairs;

		try{
			DefaultHttpClient httpClient = new DefaultHttpClient();
   		 	httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 15000); 
   		 	httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 15000);
   		 	HttpPost httpPost = new HttpPost(url);
   		 	
   		 	nameValuePairs = new ArrayList<NameValuePair>();
   		 	nameValuePairs.add(new BasicNameValuePair("user", params));
			httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs,HTTP.UTF_8));
	        
			HttpResponse rsp = httpClient.execute(httpPost);
			HttpEntity httpEntity = rsp.getEntity();
			displayString = EntityUtils.toString(httpEntity);
		}
		catch (Exception e){
			e.printStackTrace();
		}
		return displayString;
	}
}

